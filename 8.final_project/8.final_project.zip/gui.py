# Author: Josh Cowan
# Date: January 24, 2021
# Filename: gui.py
# Descirption: Run the GUI part of the program

from main import main

main()